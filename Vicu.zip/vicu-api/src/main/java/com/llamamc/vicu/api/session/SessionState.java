package com.llamamc.vicu.api.session;

public enum SessionState {
	HANDSHAKE,
	STATUS,
	LOGIN,
	PLAY
}
