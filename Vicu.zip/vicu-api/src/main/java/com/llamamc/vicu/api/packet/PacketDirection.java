package com.llamamc.vicu.api.packet;

public enum PacketDirection {
	CLIENT_TO_PROXY,
	PROXY_TO_SERVER
}
